# Modernização da Página Pessoal

Este trabalho está dividido em **duas tarefas independentes**: primeiro a remoção da estrutura atual e, em seguida, a criação da nova infraestrutura.

---

## Tarefa 1 — Deletar a estrutura atual

### Resumo
Remover completamente a implementação existente da página para começarmos de uma base limpa.

### Escopo
- [ ] Remover os arquivos HTML existentes (ex.: `index.html` e variações).
- [ ] Remover os arquivos de estilo (ex.: `styles.css`).
- [ ] Remover os scripts existentes (ex.: `main.js` e demais `.js`).
- [ ] Remover as imagens e ícones antigos (logo, avatar, favicon).
- [ ] Remover pastas de assets que não serão reaproveitadas.
- [ ] Remover qualquer arquivo de configuração/documentação obsoleto ligado à versão antiga.

### Critérios de aceite
- [ ] O repositório fica sem os arquivos da implementação anterior.
- [ ] Não restam referências quebradas nem assets órfãos.
- [ ] O repositório está pronto para receber a nova estrutura.

---

## Tarefa 2 — Criar a nova infraestrutura

### Resumo
Construir a nova página "About" simplificada, responsiva e com suporte a múltiplos idiomas (PT/EN).

### Objetivos
- Página enxuta, sem paleta de comandos (⌘K), focada em leitura.
- Header e menu totalmente responsivos, inclusive em telas pequenas.
- Troca de idioma entre Português e Inglês.
- Navegação com rolagem suave para as âncoras.

### Escopo

#### 1. Estrutura da página
- [ ] Criar a página principal simplificada, sem menu de comandos (⌘K) nem markup de command-bar/toast.
- [ ] Manter apenas os links de navegação essenciais.
- [ ] Incluir uma seção `Articles` (`#articles`).

#### 2. Identidade visual
- [ ] Definir um SVG como favicon e como logo do header.

#### 3. Organização de assets
- [ ] Estruturar os scripts em `assets/js/`.
- [ ] Estruturar as imagens em `assets/images/` e referenciá-las corretamente (logo, avatar, favicon).

#### 4. Responsividade do header e menu
- [ ] Manter o header em uma única linha em telas pequenas (logo à esquerda, ações à direita).
- [ ] Fazer o menu de navegação ocupar o espaço central e rolar horizontalmente quando não houver espaço, sem quebrar o layout nem empurrar os botões de ação.
- [ ] Ajustar o layout da introdução (foto + mini bio) para empilhar em telas menores.

#### 5. Seletor de idioma (i18n)
- [ ] Adicionar um seletor de idioma no header com opções Português e Inglês.
- [ ] Traduzir todos os textos visíveis (tagline, introdução, bio, botões, títulos de seção e `aria-label`s) via atributos `data-en`/`data-pt` (e variações para HTML e aria).
- [ ] Persistir a escolha do idioma no `localStorage` e usar o idioma do navegador como padrão inicial.

#### 6. Navegação suave
- [ ] Adicionar rolagem suave (`scroll-behavior: smooth`) ao clicar em links de âncora (ex.: `Articles`).

#### 7. Acessibilidade
- [ ] Respeitar `prefers-reduced-motion: reduce`, desativando animações e a rolagem suave.
- [ ] Garantir `aria-label`/`aria-*` corretos no seletor de idioma e nos botões de ação.

### Critérios de aceite
- [ ] A página carrega sem a paleta de comandos e sem erros no console.
- [ ] Em larguras pequenas, o header não quebra e o menu rola horizontalmente quando necessário.
- [ ] A troca de idioma atualiza todo o conteúdo e persiste após recarregar a página.
- [ ] O clique em `Articles` rola suavemente até a seção.
- [ ] Com movimento reduzido ativado, não há animações nem rolagem suave.

### Notas técnicas
- Stack: HTML/CSS/JS puro, sem frameworks (destino GitHub Pages).
- Suporte a tema claro/escuro via `data-theme` e `localStorage`.
