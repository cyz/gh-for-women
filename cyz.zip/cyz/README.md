# username.github.io

A minimal personal "about" page. Built as a simple composition of HTML, CSS,
and JavaScript — no frameworks and no build step.

## Features

- Semantic HTML with top nav, hero, copy-paste bio, and social footer.
- Dark and light themes with a toggle. The choice is saved in `localStorage`
  and the first visit follows your OS `prefers-color-scheme`.
- "Copy Bio" button that copies the bio text to the clipboard.
- Responsive and keyboard accessible.

## File structure

```
.
├── index.html      # markup and content
├── assets/         # css/, js/, images/ (avatar + favicon placeholders)
├── .nojekyll       # serve files as-is (skip Jekyll)
└── README.md
```

## Run locally

Open `index.html` directly, or serve it:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Publish with GitHub Pages

1. Create a repository named `username.github.io` (use your real GitHub username).
2. Push these files to the `main` branch root.
3. Go to **Settings → Pages** and set **Source** to *Deploy from a branch*,
   branch `main`, folder `/ (root)`.
4. Your site goes live at `https://username.github.io`.

## Customize

Replace the placeholder text in `index.html` (name, intro, bio, and social
links), swap the avatar image for your own photo, and adjust the theme
colors in the `:root` / `[data-theme]` blocks of `assets/css/styles.css`.

## License

MIT
